package com.example.batteryguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BatteryGuardService : Service() {

    companion object {
        const val THRESHOLD = 10          // lock below this %
        const val EMERGENCY_SNOOZE_MS = 60_000L
    }

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var levelText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var snoozeUntil = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = evaluate(intent)
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("guard", "Battery Guard", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, "guard")
            .setContentTitle("Battery Guard active")
            .setContentText("Locks the phone below $THRESHOLD% until charging")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setOngoing(true)
            .build()
        startForeground(1, notification)

        // ACTION_BATTERY_CHANGED must be registered at runtime; it also returns the current state.
        val sticky = registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        sticky?.let { evaluate(it) }
    }

    private fun evaluate(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val pct = if (level >= 0) level * 100 / scale else 100

        val shouldLock = pct < THRESHOLD && !plugged
        if (shouldLock && System.currentTimeMillis() >= snoozeUntil) show(pct) else hide()
    }

    private fun show(pct: Int) {
        if (!Settings.canDrawOverlays(this)) return
        if (overlay != null) { levelText?.text = "$pct%"; return }

        levelText = TextView(this).apply {
            text = "$pct%"; textSize = 64f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val message = TextView(this).apply {
            text = "Battery critically low.\nPlug in your charger to unlock."
            textSize = 20f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 32, 0, 64)
        }
        val emergency = Button(this).apply {
            text = "Emergency call"
            setOnClickListener {
                snoozeUntil = System.currentTimeMillis() + EMERGENCY_SNOOZE_MS
                hide()
                startActivity(
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                handler.postDelayed({
                    registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { evaluate(it) }
                }, EMERGENCY_SNOOZE_MS + 500)
            }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            isClickable = true        // swallow all touches
            isFocusable = true
            addView(levelText); addView(message); addView(emergency)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        )
        wm.addView(root, params)
        overlay = root
    }

    private fun hide() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        levelText = null
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        hide()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
