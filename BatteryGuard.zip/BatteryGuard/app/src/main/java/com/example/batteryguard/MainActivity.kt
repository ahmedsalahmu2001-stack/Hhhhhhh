package com.example.batteryguard

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        val button = Button(this).apply {
            text = "Grant permission / Start"
            setOnClickListener { setup() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(TextView(context).apply {
                text = "Battery Guard"; textSize = 28f; gravity = Gravity.CENTER
            })
            addView(status)
            addView(button)
        })
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) startGuard()
        refresh()
    }

    private fun setup() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else startGuard()
        refresh()
    }

    private fun startGuard() {
        ContextCompat.startForegroundService(this, Intent(this, BatteryGuardService::class.java))
    }

    private fun refresh() {
        status.text = if (Settings.canDrawOverlays(this))
            "Active. Phone locks below ${BatteryGuardService.THRESHOLD}% until plugged in."
        else "Overlay permission needed."
    }
}
